import { NextResponse } from 'next/server';

const BASE_ID = 'appwCQgFZZYlYN4SG';
const AIRTABLE_URL = 'https://api.airtable.com/v0';

function getHeaders() {
  const pat = process.env.AIRTABLE_PAT;
  if (!pat) throw new Error('AIRTABLE_PAT not set');
  return {
    'Authorization': `Bearer ${pat}`,
    'Content-Type': 'application/json',
  };
}

// GET /api/airtable?table=TABLE_ID&pageSize=100&offset=xxx
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const table = searchParams.get('table');
    const pageSize = searchParams.get('pageSize') || '100';
    const offset = searchParams.get('offset');

    if (!table) return NextResponse.json({ error: 'table required' }, { status: 400 });

    let url = `${AIRTABLE_URL}/${BASE_ID}/${table}?pageSize=${pageSize}`;
    if (offset) url += `&offset=${offset}`;

    const res = await fetch(url, { headers: getHeaders(), cache: 'no-store' });
    const data = await res.json();

    if (!res.ok) return NextResponse.json(data, { status: res.status });
    return NextResponse.json(data);
  } catch (e) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

// POST /api/airtable { table, records, action }
// action: "create" | "update" | "delete"
export async function POST(request) {
  try {
    const body = await request.json();
    const { table, records, action } = body;

    if (!table) return NextResponse.json({ error: 'table required' }, { status: 400 });

    let url = `${AIRTABLE_URL}/${BASE_ID}/${table}`;
    let method = 'POST';
    let payload;

    if (action === 'update') {
      method = 'PATCH';
      payload = { records };
    } else if (action === 'delete') {
      method = 'DELETE';
      const ids = records.map(r => `records[]=${r}`).join('&');
      url += `?${ids}`;
      const res = await fetch(url, { method, headers: getHeaders() });
      const data = await res.json();
      return NextResponse.json(data, { status: res.status });
    } else {
      payload = { records, typecast: true };
    }

    const res = await fetch(url, {
      method,
      headers: getHeaders(),
      body: JSON.stringify(payload),
    });
    const data = await res.json();

    if (!res.ok) return NextResponse.json(data, { status: res.status });
    return NextResponse.json(data);
  } catch (e) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
