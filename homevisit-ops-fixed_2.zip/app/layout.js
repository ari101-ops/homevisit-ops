export const metadata = {
  title: 'HomeVisitOps',
  description: 'Home visit dispatch and management',
  viewport: 'width=device-width, initial-scale=1, maximum-scale=1',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, padding: 0, background: '#f8fafc' }}>
        {children}
      </body>
    </html>
  );
}
